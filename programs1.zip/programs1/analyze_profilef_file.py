
import pstats

p = pstats.Stats("profile_output.prof")

p.strip_dirs().sort_stats("cumtime").print_stats(100)