

name = input("Enter any name :")
print(name)

val = 10
print(val)
print(id(val))

alist = [10,20,30]
print(id(alist))

print(max(alist))

print(min(alist))

print(sum(alist))


atup = tuple(alist)
print(atup)

name = 'python'
print(list(name))