
import collections

grades = [('rita', 81), ('Bob', 90), ('rita', 82), ('Bob', 75), ('rita', 89)]

student_grades = collections.defaultdict(list)

#{'Rita': [81, 82, 89], 'Bob': [90, 75]}

for name,grade in grades:
    student_grades[name].append(grade)
print(student_grades)

print(student_grades['rao'])

########
from collections import defaultdict
words = ['apple', 'banana', 'apple', 'orange', 'banana', 'apple']
word_count = defaultdict(int)
for word in words:
    word_count[word] += 1
print(word_count)
#{'apple': 3, 'banana': 2, 'orange': 1})



