import time
start = time.time()


################################
s = "abracadabra"

##Output:
#{'a': 5, 'b': 2, 'r': 2, 'c': 1, 'd': 1}
data = dict()
alist = list(s)  # convert string to list
for item in set(alist):
    data[item] = alist.count(item)
print(data)


###### using collections
import collections
s = "abracadabra"
counter = collections.Counter(s)
print(dict(counter))


###
import heapq
list1 = [1, 3, 5]
list2 = [2, 4, 6]
list3 = [0, 7, 8]

output = list(heapq.merge(list1,list2,list3))
print(output)
#write a program to read the above lists and display the sorted values in list.


import heapq
alist = [12,23,4,2,56,7,44,87,45]
smallest_values = heapq.nsmallest(2,alist)
largest_values = heapq.nlargest(2,alist)

print("smallest values :",smallest_values)
print("largest values", largest_values)





end = time.time()

print("Total time taken :", end-start)