
import os
for val in range(1,11):
    dirname = "dir" + str(val)
    if os.path.isdir(dirname):
        print(dirname,"exists...")
    else:
        os.mkdir(dirname)


import os
for val in range(1,11):
    dirname = "dir" + str(val)
    if os.path.isdir(dirname):
        os.rmdir(dirname)
    else:
        print(dirname,"not found")