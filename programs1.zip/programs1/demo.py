nums = [7, 2, 5, 3, 9, 1, 6]
nums.sort()
print(nums[:4])
output = [nums[x] for x in range(0,4,1)]
print(output)
 
