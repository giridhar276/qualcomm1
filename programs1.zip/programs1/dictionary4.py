
data = {
  "organization": {
    "departments": [
      {
        "id": 1,
        "name": "Engineering",
        "employees": [
          {
            "id": 101,
            "name": "Alice",
            "position": "Software Engineer",
            "projects": [
              {
                "id": "P001",
                "name": "Project Alpha",
                "status": "ongoing"
              },
              {
                "id": "P002",
                "name": "Project Beta",
                "status": "completed"
              }
            ]
          },
          {
            "id": 102,
            "name": "Bob",
            "position": "DevOps Engineer",
            "projects": [
              {
                "id": "P003",
                "name": "Project Gamma",
                "status": "planned"
              }
            ]
          }
        ]
      },
      {
        "id": 2,
        "name": "Marketing",
        "employees": [
          {
            "id": 201,
            "name": "Carol",
            "position": "Marketing Manager",
            "campaigns": [
              {
                "id": "C001",
                "name": "Campaign Spring",
                "budget": 5000
              },
              {
                "id": "C002",
                "name": "Campaign Summer",
                "budget": 7500
              }
            ]
          }
        ]
      }
    ]
  }
}






for item in data["organization"]['departments']:
    print(item)