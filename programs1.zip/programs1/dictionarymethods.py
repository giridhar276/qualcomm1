book   = {"chap1":10 ,"chap2":20  ,"chap3": 30 }
print(book)
print(book['chap1'])  # 10
book["chap1"] = 100
# display keys
print(book.keys())

for key in book.keys():
    print(key)

# display values
print(book.values())

for value in book.values():
    print(value)

# display items
print(book.items())

# remove key-value from the dict
book.pop('chap1')
print("After pop :",book)
# remove teh last key-value pair
book.popitem()
print("After popitem:",book)

newbook = {"chap5":50,"chap6":60}
book.update(newbook)
print(book)

book1 = {"chap1":10,"chap2":20}
book2 = {"chap3":30 ,"chap4":40}
finalbook = {**book1,**book2}
print(finalbook)


#*data ---> tuple
#**book ---> dict