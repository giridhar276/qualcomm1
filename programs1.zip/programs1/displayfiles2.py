

import os
try:
    files = os.listdir("C:\\")
    for file in files:
        print(file)
except Exception as err:
    print(err)