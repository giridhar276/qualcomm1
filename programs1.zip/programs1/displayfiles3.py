

import os
try:
    files = os.listdir()
    for file in files:
        if file.endswith(".py"):
            #os.remove(file)
except Exception as err:
    print(err)