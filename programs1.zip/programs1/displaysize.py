

import os
try:
    files = os.listdir()
    for file in files:
        if os.path.isfile(file):
            print(file)
            print(os.path.getsize(file),"bytes")
            print("-------------------")
except Exception as err:
    print(err)