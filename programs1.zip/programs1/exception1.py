import csv
try:
    with open("./csvfiles/adult.csv","r") as fobj:
        # convert file object to csv object
        data = csv.reader(fobj)
        for line in data:
            print("Workclass:",line[1])
            print("education:",line[3]) 
except Exception as err:
    print(err)


import csv
try:
    with open("./csvfiles/adult.csv","r") as fobj:
        # convert file object to csv object
        data = csv.reader(fobj)
        for line in data:
            print("Workclass:",line[1])
            print("education:",line[3]) 
except TypeError as err:
    print("Invalid input")
except ValueError as err:
    print("Invalid operation")
except (IndexError,KeyError) as err:
    print("Invalid input or key")
except Exception as err:
    print(err)