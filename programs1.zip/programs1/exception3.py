
#case1: If any error found in the try block.. except gets executed
#case2: If no error in the try block ....... else will be executed

import csv
try:
    fobj =  open("./csvfiles/adult.csv","r") 

except Exception as err:
    print(err)
else:
    try:
        # convert file object to csv object
        data = csv.reader(fobj)
        for line in data:
            print("Workclass:",line[1])
            print("education:",line[3]) 
    except Exception as err:
        print(err)
finally:
    fobj.close()
    print("file is closed")

