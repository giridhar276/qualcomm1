


name = 'python'
if not name.isupper():
    raise Exception("Error occured")