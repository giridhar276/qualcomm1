#- reading the file line by line using fobj
with open("customers.txt","r") as fobj:
    for line in fobj:
        print(line.strip())


#using fobj.readlines()  -----> output in list
with open("customers.txt","r") as fobj:
    #print(fobj.readlines())
    for line in fobj.readlines():
        print(line)

#using fobj.read()      -------> output in string
# not suggestable for reading flat files
with open("customers.txt","r") as fobj:
    print(fobj.read())
    #print(type(fobj.read()))

#using csv library
import csv
with open("customers.txt","r") as fobj:
    # convert file object to csv object
    data = csv.reader(fobj)
    for line in data:
        print(line)   # each line gets converted to the list automatically

# pandas - is the third party library - need to install this explicity
# pip install pandas

import pandas
df = pandas.read_csv("customers.txt")
print(df)