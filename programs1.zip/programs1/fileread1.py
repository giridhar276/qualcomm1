
'''
write a program to read adult.csv and display workclass and education columns information.

'''

import csv
with open("./csvfiles/adult.csv","r") as fobj:
    # convert file object to csv object
    data = csv.reader(fobj)
    for line in data:
        print("Workclass:",line[1])
        print("education:",line[3]) 
