'''
write a program to read adult.csv and display the below output:

output:
  
Total Male count :  3434
Total Female count:  34
'''

import csv
mcount = 0
fcount = 0
with open("./csvfiles/adult.csv","r") as fobj:
    # convert file object to csv object
    data = csv.reader(fobj)
    for line in data:
        gender = line[9]
        if gender.strip() == "Male":
            mcount = mcount +1
        else:
            fcount = fcount + 1

print("Total male count :", mcount)
print("Total female count:",fcount)