'''

  
write a program to read adult.csv and display all the unique workclasses.

State-gov
Private
Self-emp-not-inc

'''

####### using set
import csv
workset = set()
with open("./csvfiles/adult.csv","r") as fobj:
    # convert file object to csv object
    data = csv.reader(fobj)
    for line in data:
        #print(line[1])
        workset.add(line[1])
    print(workset)
    for item in workset:
        print(item)



######## using dict
import csv
workdict = dict()
with open("./csvfiles/adult.csv","r") as fobj:
    # convert file object to csv object
    data = csv.reader(fobj)
    for line in data:
        workclass = line[1]
        workdict[workclass]= 1

    for item in workdict:
        print(item)