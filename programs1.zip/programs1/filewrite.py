
# legacy way  # traditional way
fobj = open("customers.txt","w")
fobj.write("ibm\n")
fobj.write("microsoft\n")
fobj.write("servicenow\n")
fobj.close()

# writing numbers to the file
fn = open("numbers.txt","w")
for number in range(1,11):
    fn.write(str(number) + "\n")
fn.close()


# context manager
# If any line starts with keyword with ... we call it context manager
# Advantage: file gets closed automatically

with open("customers.txt","w") as fobj:
    fobj.write("ibm\n")
    fobj.write("microsoft\n")

