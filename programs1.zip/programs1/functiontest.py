def name():
    return list(range(1,10000))


print(name())