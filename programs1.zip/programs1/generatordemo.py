
def displaynumbers():
    for val in range(1,100):
        print(val)

displaynumbers()





# using generator -
def number_generator():
    for val in range(1,100):
        yield val

for number in number_generator():
    print(number)




#####
def chunked(iterable, chunk_size):
    chunk = []
    for item in iterable:
        chunk.append(item)
        if len(chunk) == chunk_size:
            yield chunk
            chunk = []
    if chunk:
        yield chunk

# Usage
data = list(range(1, 11))
for chunk in chunked(data, 3):
    print(chunk)



### file handling using generator

import os

def read_files(*filenames):
    for filename in filenames:
        if os.path.exists(filename):
            with open(filename, 'r') as file:
                for line in file:
                    yield line.strip()
        else:
            print(f"File {filename} does not exist.")

# Usage
for line in read_files('file1.txt', 'file2.txt'):
    print(line)
