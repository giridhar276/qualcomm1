

name = 'python programming'
if 'gram' in name:
    print("substrings exits..!!")


alist = [10,20,30]
if 20 in alist:
    print("exists")

book = {"chap1":10 ,"chap2":20}
if 'chap1' in book:
    print("key exists..")