

#1st method

ip = "192.168.{}.{}"

for val in range(0,2):
    for ival in range(1,11):
        print(ip.format(val,ival))




ip = "192.168"
for val in range(0,2):
    for ival in range(1,11):
        newip = ip + "." + str(val)
        finalip = newip + "." + str(ival)
        print(finalip)


