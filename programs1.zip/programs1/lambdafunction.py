def display(a,b):
    c = a+b
    return c
total = display(10,20)
print(total)


# lambda function
# inline function # anonymous function  
#syntax:   
#functioname = lambda variables: expression
# Advantage: expression will be replaced in the function body
# lambda is the replacment of single liner function

display = lambda a,b: a + b
total = display(10,20)
print(total)


toupper = lambda x : x.upper() + " programming".upper()
output = toupper("python")
print(output)


alist = [10,20,30,40]

#output
#[15,25,35,45]
# method1 - traditional way
alist = [10,20,30,40]
blist = []
for val in alist:
    blist.append(val +5)
print(blist)

# method2  - using map()
#map(function,iterable)
alist = [10,20,30,40]
def increment(x):
    return x + 5
print(list(map(increment,alist)))

# method3 - map with lambda
alist = [10,20,30,40]
increment = lambda x : x + 5
print(list(map(increment,alist)))

# writing in the single line–
print(list(map(lambda x : x + 5,alist)))

alist = ["google","facebook","salesforce"]
#["www.google.com","www.facebook.com","www.salesforce.com"]
print(list(map(lambda x : "www." + x +".com",alist)))




  
data = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]

#        list(map(lambda x: expression , data))
output = list(map(lambda x: sum(map(lambda y:y**2, x)), data))   
print(output)


##output
#['OLLEH', 'DLROW', 'NOHTYP']]
data = ['hello', 'world', 'python']
output = list(map(lambda x : x[::-1],data))
print(output)

  
#output : [5, 7, 9]
list1 = [1, 2, 3]
list2 = [4, 5, 6]
output = list(map(lambda x,y: x+y, list1,list2))
print(output)




data = {'a': 2, 'b': 3, 'c': 4}
print(data.items())
#                      [a,2]-->['A',4]
#                      [b,3]-->['B',9]
output = dict(map(lambda x: (x[0].upper(),x[1]**2) , data.items()))
print(output)
#{'A': 4, 'B': 9, 'C': 16}


dict1 = {'a': 1, 'b': 2, 'c': 3}
dict2 = {'a': 4, 'b': 5, 'c': 6}
##{'a': 5, 'b': 7, 'c': 9}
#                           (a, 1+4 )                   [a,b,c]
output = dict(map(lambda x :(x,dict1[x] + dict2[x]), dict1.keys()))
print(output)



#filter()
alist = [1,2,3,4,5,6,7,8]

output = list(filter(lambda x:x%2==0,alist))
print(output)


