alist = [10,56,23,67,3,6,7,345,67,23]
print(alist)
print(alist[0:8])

#append - single value
alist.append(93)
alist.append(39)
print("Aftera appending:",alist)

#list.extend(list)   # adding multiple values
alist.extend([93,17,59,34])
print(alist)

#list.insert(index,value)
alist.insert(1,100)
print("After inserting:",alist)
alist.insert(4,50)
print("After inserting:",alist)

#list.pop(index)
value_removed = alist.pop(1)
print(value_removed)

#list.remove(value)  # value that is existing in the list
alist.remove(23)
print("After removing:",alist)

#sorting the values
alist.sort()
print('after sorting:',alist)

alist.sort(reverse=True)
print("Descending order :",alist)

alist.reverse()
print("after reversing:",alist)




for value in alist:
    print(value)