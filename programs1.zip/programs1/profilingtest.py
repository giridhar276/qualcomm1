
import cProfile


def my_function():
    total = 0
    for i in range(1000000):
        total += i
    return total

#print(my_function())

cProfile.run("my_function()")