import time
import cProfile
def long_task():
    time.sleep(3)
    return "long Task Completed"

def short_task():
    time.sleep(0.1)
    return "short Task Completed"

def main():
    for _ in range(5):
        print(long_task())
        print(short_task())
#main()
cProfile.run("main()","output.prof")
