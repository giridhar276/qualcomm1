

print("python programming")

print('machine learning')