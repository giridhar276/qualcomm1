  

name = 'python programming'
print(name)
print("I love",name)

# slicing - extracting the part of the string
#string[start:stop:step]
print(name[0:4])
print(name[5:10])
print(name[0:18:2])
print(name[1:18:2])
print(name[9:18:5])
print(name[::])  #  start =0   stop=18  step=1
print(name[:])   #  start =0   stop=18  step=1
print(name[-1])
print(name[-5])
print(name[-7:-4])
print(name[::-1])

first = "python"
second = "programming"
final = first + second   # + is the concatenation operator
print(final)
print(final * 4)          # * is the repetition operator

# python string methods

name = "python programming"
print(name.capitalize())
print(name.center(50))
print(name.center(50,"*"))
print(name.count('p'))
print(name.count("z"))

print(name.startswith("p"))
print(name.startswith("q"))
print(name.endswith("g"))

print(name.isalnum())  #False
print(name.isalpha())
print(name.istitle())
print(name.isupper())
print(name.islower())

print(name.split(" "))

data = "a:b:c"
print(data.split(":"))  #['a', 'b', 'c']

print(name.find("gra"))  #10  # 10 is the index of g

#method1
aname = "I love {} and {}"
print(aname.format("python","java"))
print(aname.format("1","2"))
# method2
price=30
print(f"the price is {price} dollars")


print(name.replace("python","scala"))


name = "python"
print(name.isupper())
# if-else
if name.isupper():
    print("inside if")
    print("String is upper")
else:
    print("inside else")
    print("String is lower")


# if-elif-elif-else
if name.startswith("py"):
    print("python programming")
elif name.startswith("un"):
    print("unix")
elif name.startswith("java"):
    print("java programming")
else:
    print("some other language")





# for loop with string
name = 'python'
for char in name:
    print(char)

# display numbers
# range(start,stop,step)
for val in range(1,11,1):
    print(val)

pdb.set_trace()  
# iterating list
alist = [10,20,30,40]
for item in alist:
    print(item)