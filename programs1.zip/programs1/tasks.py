'''
write a program to display the below information

1) current working directory  
2) login name
3) current process id
4) current python version
5) all the libraries available in python
6) all the environment variables
7) operating system name
8) platform name
9)current date and time
10)statistics of adult.csv file
11)create empty file with today's timestamp

'''
import sys
import os
import platform
import datetime
print(os.getcwd())
print(os.getlogin())
process_id = os.getpid()
print(process_id)
# display version
python_version = sys.version
print(python_version)
# display libraries
for key in sys.modules.keys():
    print(key)
#6. All the environment variables
env_vars = os.environ
for key, value in env_vars.items():
    print(key)
    print(value)

# display platformname
platform_name = platform.system()
print(platform_name)
# display date and time
current_datetime = datetime.datetime.now()
print(current_datetime)
# get statistics
filename = "./csvfiles/adult.csv"
print(os.stat(filename))
modified_time =os.stat(filename).st_mtime
print(modified_time)
#converting epoch to human readable format
human_readable_date = datetime.datetime.fromtimestamp(modified_time)
print(human_readable_date)
# creating empty file
import time
filename = time.strftime("%d_%b_%Y.csv")
print(filename)
with open(filename,"w") as fw:
    pass