

import timeit
time_taken = timeit.timeit("sum(range(100))",number = 1000)
print("total time taken :",time_taken)






from timeit import Timer
# Define a code block as a function
def test():
    sum(range(100))
# Create a Timer object
t = Timer(test)
# Time the execution
time_taken = t.timeit(number=1000)
print(time_taken)




setup_code = 'from math import sqrt'
test_code = 'sqrt(25)'
# Measure execution time with setup code
time_taken = timeit.timeit(test_code, setup=setup_code, number=1000)
print(f'Time taken: {time_taken} seconds')

#############################################################################################

# Setup code
setup = '''
import random
random_list = [random.randint(1, 100) for _ in range(1000)]
'''

# List comprehension
list_comp = '''
squares = [x**2 for x in random_list]
'''
# For loop
for_loop = '''
squares = []
for x in random_list:
    squares.append(x**2)
'''
# Timing
time_list_comp = timeit.timeit(list_comp, setup=setup, number=1000)
time_for_loop = timeit.timeit(for_loop, setup=setup, number=1000)

print(f'List comprehension time: {time_list_comp} seconds')
print(f'For loop time: {time_for_loop} seconds')















data = {"unix":50,"java":4,"windows":1}


sorted_data = {   k:v   for k,v  in data.items()}
sorted_data = {   k:v   for k,v  in    sorted(data.items() , key = lambda item:item[1])   }
print(sorted_data)




