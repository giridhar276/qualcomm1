
#list
alist = [45,43,456,43,90]
alist[0] = 450
print("After replacing :",alist)

#tuple
atup = (56,67,43)
alist = list(atup)   # typecasting - converting to list
alist[0] = 560       # making changes
atup = tuple(alist)  # converting back to tuple
print("After replacing :",atup)

