#fixed arguments
def display(a,b):
    print(a,b)
display(10,20)

# default arguments
def display(a = 0,b = 0,c = 0):
    print(a,b,c)
display()
display(10)
display(10,20)
display(10,20,30)

#keyword arguments
def display(b,a,c):
    print(a,b,c)
display(a=10,b=20,c=30)

# variable length arguments
def display(*args):   # args is tuple
    print(type(args))
    for value in args:
        print(value)
display(10,20,30,40,50,56,43,67,32,65,2,45,32,4,"unix")

def display(**kwargs):  # kwargs is the dictionary
    print(type(kwargs))
    for k,w in kwargs.items():
        print(k,w)

display(first = 10 , second = 20,third = 30)